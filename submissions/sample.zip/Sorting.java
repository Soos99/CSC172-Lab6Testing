/******************************************************************************
 *  Compilation:  javac Sorting.java
 *  Execution:    java Sorting input.txt AlgorithmUsed
 *  Dependencies: StdOut.java In.java Stopwatch.java
 *  Data files:   http://algs4.cs.princeton.edu/14analysis/1Kints.txt
 *                http://algs4.cs.princeton.edu/14analysis/2Kints.txt
 *                http://algs4.cs.princeton.edu/14analysis/4Kints.txt
 *                http://algs4.cs.princeton.edu/14analysis/8Kints.txt
 *                http://algs4.cs.princeton.edu/14analysis/16Kints.txt
 *                http://algs4.cs.princeton.edu/14analysis/32Kints.txt
 *                http://algs4.cs.princeton.edu/14analysis/1Mints.txt
 *
 *  A program to play with various sorting algorithms. 
 *
 *
 *  Example run:
 *  % java Sorting 2Kints.txt  2
 *
 ******************************************************************************/
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.io.IOException;

public class Sorting {


 /**
     * 
     * Sorts the numbers present in the file based on the algorithm provided.
     * 0 = Arrays.sort() (Java Default)
     * 1 = Bubble Sort
     * 2 = Selection Sort 
     * 3 = Insertion Sort 
     * 4 = Mergesort
     * 5 = Quicksort
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) throws IOException  {
        //
    }

    public static void defaultSort(int[] x) {
        Arrays.sort(x);
    }
    public static void bubbleSort(int[] x){
        for (int i = 0; i < x.length; i++){
            boolean swap = false;
            for (int j = x.length - 1; j > i; j--){
                if (x[j] < x[j-1]){
                    int temp = x[j];
                    x[j] = x[j-1];
                    x[j-1] = temp;
                    swap = true;
                }
            }
            if (!swap)
                return;
        }
    }
    public static void selectionSort(int[] x){
        for (int i = 0; i < x.length - 1; i++){
            int min = x[i];
            int index = i;
            for (int j = i + 1; j < x.length; j++){
                if (x[j] < min){
                    min = x[j];
                    index = j;
                }
            }
            x[index] = x[i];
            x[i] = min;
        }
    }
    public static void insertionSort(int[] x){
        for (int i = 1; i < x.length; i++){
            int j = i;
            int num = x[i];
            while (j > 0 &&(num < x[j-1])){
                x[j] = x[j-1];
                j--;
            }
            x[j] = num;
        }
    }
    public static void mergeSort(int[] x) {
        mergeSort(x,0,x.length - 1);
    }
    public static void mergeSort(int[] x,int start,int end) {
        if (start >= end) return;
        int mid = (start + end) / 2;
        mergeSort(x, start, mid);
        mergeSort(x, mid + 1, end);
        merge(x, start, end);
    }
    public static void merge(int[] x, int start,int end) {
        int mid = (start + end) / 2;
        int x1 = mid - start + 1;
        int x2 = end - mid;
        int[] arr1 = new int[x1];
        for (int i = 0; i < x1; i++) {
            arr1[i] = x[start + i];
        }
        int[] arr2 = new int[x2];
        for (int i = 0; i < x2; i++) {
            arr2[i] = x[mid + 1 + i];
        }
        int curr1 = 0;
        int curr2 = 0;
        while (curr1 < arr1.length && curr2 < arr2.length) {
            if (arr1[curr1] < arr2[curr2]) {
                x[start + curr1 + curr2] = arr1[curr1];
                curr1++;
            } else {
                x[start + curr1 + curr2] = arr2[curr2];
                curr2++;
            }
        }
        while (curr1 < arr1.length) {
            x[start + curr1 + curr2] = arr1[curr1];
            curr1++;
        }
        while (curr2 < arr2.length) {
            x[start + curr1 + curr2] = arr2[curr2];
            curr2++;
        }
    }

    public static void quickSort(int[] x){
        quickSort(x,0,x.length - 1);
    }
    public static void quickSort(int[] x,int start,int end){
        int index = x[(int) (start + Math.random()*(end-start+1))];
        int i = start;
        int j = end;
        do {
            while (x[i] < index) i++;
            while (index < x[j]) j--;
            if (i <= j) {
                int temp = x[i];
                x[i] = x[j];
                x[j] = temp;
                i++;
                j--;
            }
        } while (i <= j);
        if (start < j)
            quickSort(x, start, j);
        if (i < end)
            quickSort(x, i, end);
    }
} 


